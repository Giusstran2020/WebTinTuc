// $(document).ready(function() {
//     $.ajax({
//         type: "GET",
//         cache: false,
//         url: '/lab-04/api/',
//         success: function (res) {
//             var data =  JSON.parse(res);
//             $.each(data, function() {
                
//             }); 
//         }
//     });
// });