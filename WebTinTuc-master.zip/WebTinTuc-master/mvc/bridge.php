<?php
    require_once "./mvc/core/app.php";
    require_once "./mvc/core/controller.php";
    require_once "./mvc/core/config.php";
    require_once "./mvc/core/database.php";
?>